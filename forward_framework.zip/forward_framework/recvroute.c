#include "recvroute.h"

int static_route_get(struct selfroute *selfrt)
{
	
}
