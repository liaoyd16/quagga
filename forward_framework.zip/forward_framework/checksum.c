#include "checksum.h"

int check_sum(unsigned short *iphd,int len,unsigned short checksum)
{
   
}
unsigned short count_check_sum(unsigned short *iphd)
{
    
}
