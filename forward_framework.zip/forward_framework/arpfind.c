#include "arpfind.h"

int arpGet(struct arpmac *srcmac,char *ifname, char *ipStr)  
{  
   
    return 0;  
}  
                                                                                                        
                                                                                                          
                                                                                                            
                                                                                                              
